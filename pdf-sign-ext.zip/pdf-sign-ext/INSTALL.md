# 安裝 pdf-sign Chrome 擴充功能

## 本機測試（開發者模式）

1. 下載並解壓縮 `pdf-sign-extension.zip`
2. 開啟 Chrome，網址列輸入 `chrome://extensions/`
3. 右上角打開「開發人員模式」
4. 點「載入未封裝項目」，選擇解壓縮後的 `pdf-sign-ext` 資料夾
5. 完成！右上角工具列會出現紅色簽名圖示
6. 點圖示 → 開啟新分頁，即可使用完整簽名工具

## 資料夾結構

```
pdf-sign-ext/
├── manifest.json          Manifest V3 設定檔
├── background.js          點圖示 → 開新分頁
├── pdf-sign.html           主要工具頁面
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── lib/                    本機函式庫（不依賴 CDN）
    ├── pdf.min.js
    ├── pdf.worker.min.js
    ├── pdf-lib.min.js
    └── signature_pad.umd.min.js
```

## 為什麼函式庫要打包進來，不能用 CDN？

Chrome Web Store 的 **Manifest V3 遠端程式碼政策**禁止擴充功能從外部 CDN 載入 JavaScript
（`<script src="https://cdn...">` 這種寫法會被拒審）。所有程式碼都必須包在擴充功能資料夾裡，
離線也要能執行。這份擴充功能已經把 PDF.js、pdf-lib、Signature Pad 三個函式庫下載並打包進 `lib/` 資料夾。

## 為什麼點圖示是開新分頁，不是彈出小視窗？

Chrome 擴充功能的 popup 視窗最大大約只有 800×600px，塞不下完整的 PDF 預覽畫布 + 拖曳側邊欄。
開新分頁能用滿整個瀏覽器視窗，簽名拖曳、縮放操作都比較順手。這也是 Loom、Grammarly 等工具常見的做法。

## 上架 Chrome Web Store（選用）

若要正式上架：

1. 準備一組 [Chrome Web Store 開發人員帳號](https://chrome.google.com/webstore/devconsole)（一次性 $5 美金註冊費）
2. 把整個 `pdf-sign-ext/` 資料夾重新壓縮成 zip
3. 到開發人員後台上傳，填寫商店說明、截圖、隱私權政策連結
4. 因為完全不連網、不蒐集資料，審核時特別要在「隱私權作法」欄位誠實填寫「不蒐集任何使用者資料」，通過機率較高
5. 送審，通常需要數天到數週不等

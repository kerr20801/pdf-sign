// pdf-sign — background service worker
// Clicking the extension icon opens the full-page tool in a new tab.
// (A small popup can't fit the PDF canvas + sidebar UI comfortably,
// so we open a real tab instead — same approach as tools like Loom.)

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({
    url: chrome.runtime.getURL('pdf-sign.html')
  });
});

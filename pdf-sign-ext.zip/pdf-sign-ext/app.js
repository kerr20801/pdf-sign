pdfjsLib.GlobalWorkerOptions.workerSrc =
  chrome.runtime.getURL('lib/pdf.worker.min.js');

const SCALE = 1.5;
let pdfJsDoc = null, currentPage = 1, totalPages = 0;
let originalBytes = null, renderTask = null;
let sigPad = null;
let activeTab = 'draw';
let currentSigDataUrl = null;   // whatever is ready to drop
let placedSigs = {};            // { page: [{x,y,w,h,dataUrl}] }

// Elements
const fileInput    = document.getElementById('file-input');
const pdfArea      = document.getElementById('pdf-area');
const dropHint     = document.getElementById('drop-hint');
const pageNav      = document.getElementById('page-nav');
const canvasWrap   = document.getElementById('canvas-wrap');
const pdfCanvas    = document.getElementById('pdf-canvas');
const sigCanvas    = document.getElementById('sig-canvas');
const penColorEl   = document.getElementById('pen-color');
const penSizeEl    = document.getElementById('pen-size');
const clearBtn     = document.getElementById('clear-btn');
const saveBtn      = document.getElementById('save-btn');
const loadBtn      = document.getElementById('load-btn');
const downloadSigBtn = document.getElementById('download-sig-btn');
const sigImgInput  = document.getElementById('sig-img-input');
const previewSec   = document.getElementById('preview-section');
const sigPreview   = document.getElementById('sig-preview');
const sigSizeEl    = document.getElementById('sig-size');
const sigSizeVal   = document.getElementById('sig-size-val');
const downloadBtn  = document.getElementById('download-btn');
const dragGhost    = document.getElementById('drag-ghost');
const sigCount     = document.getElementById('sig-count');
const prevBtn      = document.getElementById('prev-btn');
const nextBtn      = document.getElementById('next-btn');
const pageInfo     = document.getElementById('page-info');

// ── Signature Pad ─────────────────────────────────────────
sigPad = new SignaturePad(sigCanvas, {
  backgroundColor: 'rgba(0,0,0,0)',
  penColor: penColorEl.value,
  minWidth: 1, maxWidth: 2.5,
});
penColorEl.addEventListener('input', () => { sigPad.penColor = penColorEl.value; });
penSizeEl.addEventListener('input', () => {
  const v = parseFloat(penSizeEl.value);
  sigPad.minWidth = v * 0.5; sigPad.maxWidth = v;
});
sigPad.addEventListener('endStroke', () => {
  currentSigDataUrl = sigPad.toDataURL('image/png');
  showPreview(currentSigDataUrl);
});
clearBtn.addEventListener('click', () => {
  sigPad.clear();
  currentSigDataUrl = null;
  previewSec.style.display = 'none';
});
saveBtn.addEventListener('click', () => {
  if(!currentSigDataUrl){ alert('請先畫簽名'); return; }
  localStorage.setItem('saved-sig', currentSigDataUrl);
  saveBtn.textContent = '✅'; setTimeout(() => saveBtn.textContent = '💾 儲存', 1500);
});
loadBtn.addEventListener('click', () => {
  const d = localStorage.getItem('saved-sig');
  if(!d){ alert('尚未儲存過簽名'); return; }
  const img = new Image();
  img.onload = () => {
    sigPad.clear();
    sigCanvas.getContext('2d').drawImage(img, 0, 0, sigCanvas.width, sigCanvas.height);
    currentSigDataUrl = d;
    showPreview(d);
  };
  img.src = d;
});

downloadSigBtn.addEventListener('click', () => {
  if(!currentSigDataUrl){ alert('請先畫簽名或上傳圖片'); return; }
  const a = document.createElement('a');
  a.href = currentSigDataUrl;
  a.download = 'signature_' + Date.now() + '.png';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
});

// ── Tabs ─────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    activeTab = btn.dataset.tab;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b===btn));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.toggle('active', p.id==='tab-'+activeTab));
  });
});

// ── Upload ────────────────────────────────────────────────
sigImgInput.addEventListener('change', e => loadSigImg(e.target.files[0]));
function loadSigImg(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => { currentSigDataUrl = e.target.result; showPreview(e.target.result); };
  reader.readAsDataURL(file);
}

function showPreview(dataUrl){
  sigPreview.src = dataUrl;
  previewSec.style.display = 'flex';
}

// ── Size slider ───────────────────────────────────────────
sigSizeEl.addEventListener('input', () => { sigSizeVal.textContent = sigSizeEl.value + 'px'; });

// ════════════════════════════════════════════════════════
// DRAG FROM SIDEBAR PREVIEW → PDF
// Uses Pointer Events for reliable cross-browser drag
// ════════════════════════════════════════════════════════
let draggingFromSidebar = false;

sigPreview.addEventListener('pointerdown', e => {
  if(!currentSigDataUrl || !pdfJsDoc) return;
  e.preventDefault();
  draggingFromSidebar = true;
  sigPreview.setPointerCapture(e.pointerId);

  // Show ghost image following cursor
  dragGhost.src = currentSigDataUrl;
  const w = parseInt(sigSizeEl.value);
  const h = Math.round(w * 0.4);
  dragGhost.style.width  = w + 'px';
  dragGhost.style.height = h + 'px';
  dragGhost.style.display = 'block';
  moveDragGhost(e.clientX, e.clientY);
});

sigPreview.addEventListener('pointermove', e => {
  if(!draggingFromSidebar) return;
  moveDragGhost(e.clientX, e.clientY);
});

sigPreview.addEventListener('pointerup', e => {
  if(!draggingFromSidebar) return;
  draggingFromSidebar = false;
  dragGhost.style.display = 'none';

  // Find drop position relative to canvas-wrap
  const wrapRect = canvasWrap.getBoundingClientRect();
  const cx = e.clientX - wrapRect.left;
  const cy = e.clientY - wrapRect.top;

  // Check if dropped inside the PDF area
  if(cx < 0 || cy < 0 || cx > canvasWrap.offsetWidth || cy > canvasWrap.offsetHeight) return;

  const w = parseInt(sigSizeEl.value);
  const h = Math.round(w * 0.4);
  const sig = { x: cx - w/2, y: cy - h/2, w, h, dataUrl: currentSigDataUrl };
  if(!placedSigs[currentPage]) placedSigs[currentPage] = [];
  placedSigs[currentPage].push(sig);
  addSigEl(sig);
  updateUI();
});

function moveDragGhost(cx, cy){
  dragGhost.style.left = cx + 'px';
  dragGhost.style.top  = cy + 'px';
}

// ── Create a placed sig element ───────────────────────────
function addSigEl(sig){
  const div = document.createElement('div');
  div.className = 'sig-placed';
  div.style.cssText = `left:${sig.x}px;top:${sig.y}px;width:${sig.w}px;height:${sig.h}px`;

  const img = document.createElement('img');
  img.src = sig.dataUrl;
  img.draggable = false;

  const del = document.createElement('div');
  del.className = 'del-btn';
  del.textContent = '×';
  del.addEventListener('click', e => {
    e.stopPropagation();
    canvasWrap.removeChild(div);
    const arr = placedSigs[currentPage];
    const i = arr.indexOf(sig);
    if(i > -1) arr.splice(i,1);
    updateUI();
  });

  const rsz = document.createElement('div');
  rsz.className = 'rsz-handle';
  makeResizable(rsz, sig, div);

  div.appendChild(img);
  div.appendChild(del);
  div.appendChild(rsz);
  canvasWrap.appendChild(div);

  // Make it draggable within the PDF
  makeDraggable(div, sig);
}

function makeDraggable(el, sig){
  el.addEventListener('pointerdown', e => {
    if(e.target.classList.contains('del-btn') ||
       e.target.classList.contains('rsz-handle')) return;
    e.preventDefault();
    el.setPointerCapture(e.pointerId);
    const sx = e.clientX, sy = e.clientY;
    const ox = sig.x,     oy = sig.y;
    function onMove(e){
      sig.x = ox + e.clientX - sx;
      sig.y = oy + e.clientY - sy;
      el.style.left = sig.x + 'px';
      el.style.top  = sig.y + 'px';
    }
    function onUp(){
      el.removeEventListener('pointermove', onMove);
      el.removeEventListener('pointerup', onUp);
    }
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
  });
}

function makeResizable(handle, sig, el){
  handle.addEventListener('pointerdown', e => {
    e.preventDefault(); e.stopPropagation();
    handle.setPointerCapture(e.pointerId);
    const sx = e.clientX, ow = sig.w, oh = sig.h, ratio = oh/ow;
    function onMove(e){
      sig.w = Math.max(40, ow + e.clientX - sx);
      sig.h = sig.w * ratio;
      el.style.width  = sig.w + 'px';
      el.style.height = sig.h + 'px';
    }
    function onUp(){
      handle.removeEventListener('pointermove', onMove);
      handle.removeEventListener('pointerup', onUp);
    }
    handle.addEventListener('pointermove', onMove);
    handle.addEventListener('pointerup', onUp);
  });
}

// ── PDF Loading ───────────────────────────────────────────
function loadFile(file){
  if(!file||file.type!=='application/pdf'){ alert('請選擇 PDF'); return; }
  const r = new FileReader();
  r.onload = async e => {
    originalBytes = new Uint8Array(e.target.result);
    placedSigs = {}; currentPage = 1;
    await loadPdf(originalBytes);
  };
  r.readAsArrayBuffer(file);
}
async function loadPdf(bytes){
  pdfJsDoc = await pdfjsLib.getDocument({data: bytes.slice(0)}).promise;
  totalPages = pdfJsDoc.numPages;
  dropHint.style.display = 'none';
  pageNav.style.display = 'flex';
  canvasWrap.style.display = 'block';
  await renderPage(currentPage);
  updateUI();
}
async function renderPage(num){
  if(renderTask){ try{renderTask.cancel()}catch(e){} }
  // Remove old sig els
  canvasWrap.querySelectorAll('.sig-placed').forEach(el => el.remove());

  const page = await pdfJsDoc.getPage(num);
  const vp = page.getViewport({scale: SCALE});
  pdfCanvas.width = vp.width; pdfCanvas.height = vp.height;
  renderTask = page.render({canvasContext: pdfCanvas.getContext('2d'), viewport: vp});
  await renderTask.promise;

  // Re-add sig els for this page
  (placedSigs[num]||[]).forEach(sig => addSigEl(sig));
}
prevBtn.addEventListener('click', async () => { if(currentPage>1){ currentPage--; await renderPage(currentPage); updateUI(); } });
nextBtn.addEventListener('click', async () => { if(currentPage<totalPages){ currentPage++; await renderPage(currentPage); updateUI(); } });

function updateUI(){
  pageInfo.textContent = `${currentPage} / ${totalPages}`;
  prevBtn.disabled = currentPage<=1; nextBtn.disabled = currentPage>=totalPages;
  const total = Object.values(placedSigs).reduce((a,b)=>a+b.length, 0);
  sigCount.textContent = total > 0 ? `已放置 ${total} 個簽名` : '尚未放置簽名';
  downloadBtn.disabled = total === 0;
}

// ── Download ──────────────────────────────────────────────
downloadBtn.addEventListener('click', async () => {
  downloadBtn.disabled = true; downloadBtn.textContent = '處理中…';
  try {
    const {PDFDocument} = PDFLib;
    const doc = await PDFDocument.load(originalBytes.slice(0));
    for(const [pgStr, sigs] of Object.entries(placedSigs)){
      const page = doc.getPage(parseInt(pgStr)-1);
      const {height: pdfH} = page.getSize();
      for(const sig of sigs){
        const bytes = await fetch(sig.dataUrl).then(r=>r.arrayBuffer());
        const pdfImg = sig.dataUrl.includes('image/png') || !sig.dataUrl.includes('image/jpeg')
          ? await doc.embedPng(bytes) : await doc.embedJpg(bytes);
        page.drawImage(pdfImg, {
          x: sig.x/SCALE,
          y: pdfH - (sig.y+sig.h)/SCALE,
          width:  sig.w/SCALE,
          height: sig.h/SCALE,
          opacity: 0.9,
        });
      }
    }
    const blob = new Blob([await doc.save()], {type:'application/pdf'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'signed_' + Date.now() + '.pdf';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch(err){ alert('下載失敗：'+err.message); console.error(err); }
  finally { downloadBtn.disabled = false; downloadBtn.textContent = '⬇ 下載簽名 PDF'; updateUI(); }
});

// ── PDF drag & drop ───────────────────────────────────────
pdfArea.addEventListener('dragover', e => { e.preventDefault(); dropHint.classList.add('drag-over'); });
pdfArea.addEventListener('dragleave', () => dropHint.classList.remove('drag-over'));
pdfArea.addEventListener('drop', e => {
  e.preventDefault(); dropHint.classList.remove('drag-over');
  loadFile(e.dataTransfer.files[0]);
});
fileInput.addEventListener('change', e => loadFile(e.target.files[0]));
